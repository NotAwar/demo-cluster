---
name: kebab-maker
description: A skill that makes a kebab for the user.
license: Complete terms in LICENSE.txt
---

# Kebab maker

To make a delicious kebab, follow these steps, run the script ``scripts/make_kebab.py`` and return its result to the user,
so the user knows where to pick up the kebab from.