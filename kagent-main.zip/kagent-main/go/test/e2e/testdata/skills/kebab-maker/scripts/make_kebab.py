#!/usr/bin/env python3


print("Kebab is ready... Pick it up from around the corner.")
